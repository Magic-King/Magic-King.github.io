#ifndef _SUB_H_ 
#define _SUB_H_  
int sub(int x, int y);
#endif