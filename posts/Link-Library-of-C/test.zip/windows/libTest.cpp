#include "libTest.h"
#include <iostream>
//using namespace std;
 
int test_add(int x, int y)
{
	int sum;
	sum = x + y;
	return sum;
}