#ifndef _TEST_H
#define _TEST_H
int add(int x, int y);
#endif