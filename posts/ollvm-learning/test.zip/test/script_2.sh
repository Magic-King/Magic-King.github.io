echo -e "Obfuscator compile is beginning!\n"

../build/bin/clang -o clang/sub/test_sub.out -mllvm -sub test.c
../build/bin/clang -o clang/bcf/test_bcf.out -mllvm -bcf test.c
../build/bin/clang -o clang/fla/test_fla.out -mllvm -fla test.c

echo "Obfuscator Compile finished!"

