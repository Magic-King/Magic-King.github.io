echo -e "test compile is beginning!\n"

gcc -o gcc/test_gcc.out test.c
gcc -S -o gcc/test_gcc.S test.c

../build/bin/clang -o clang/test_clang.out test.c
../build/bin/clang -S -emit-llvm -o clang/test_clang.ll test.c

echo -e "test compile finished!\n"

