#include <stdio.h>
#include <stdlib.h>

int main(){
	printf("Hello LLVM");
	char *a= "Hello fucking bug";
	//a = "Hello O-LLVM!I will fuck you!";
	int sum = 0;
	for (int i = 1;i<=10;i++){
		sum += i;
	}
	printf("%s\nthe answer of what i do is %d\n",a,sum);
	printf("test finished!\n");
	return 0;
}
